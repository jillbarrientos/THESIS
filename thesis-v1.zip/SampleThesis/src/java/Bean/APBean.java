/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Bean;

/**
 *
 * @author jillianembarrientos
 */
public class APBean {
    private String BSSID;
    private String SSID;
    private String channel;
    private String IP;
    private String switchport;
    private String switchIP;
    private String encrypt;
    private String pw;

    public APBean(String BSSID, String SSID, String channel, String IP, String switchport, String switchIP, String encrypt, String pw) {
        this.BSSID = BSSID;
        this.SSID = SSID;
        this.channel = channel;
        this.IP = IP;
        this.switchport = switchport;
        this.switchIP = switchIP;
        this.encrypt = encrypt;
        this.pw = pw;
    }

    public String getBSSID() {
        return BSSID;
    }

    public String getChannel() {
        return channel;
    }

    public String getEncrypt() {
        return encrypt;
    }

    public String getIP() {
        return IP;
    }

    public String getPw() {
        return pw;
    }

    public String getSSID() {
        return SSID;
    }

    public String getSwitchIP() {
        return switchIP;
    }

    public String getSwitchport() {
        return switchport;
    }

    public void setBSSID(String BSSID) {
        this.BSSID = BSSID;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public void setEncrypt(String encrypt) {
        this.encrypt = encrypt;
    }

    public void setIP(String IP) {
        this.IP = IP;
    }

    public void setPw(String pw) {
        this.pw = pw;
    }

    public void setSSID(String SSID) {
        this.SSID = SSID;
    }

    public void setSwitchIP(String switchIP) {
        this.switchIP = switchIP;
    }

    public void setSwitchport(String switchport) {
        this.switchport = switchport;
    }
    
}
