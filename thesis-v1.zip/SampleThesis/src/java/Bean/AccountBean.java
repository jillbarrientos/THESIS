/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Bean;

/**
 *
 * @author jillianembarrientos
 */
public class AccountBean {
   private String fName;
   private String lName;
   private boolean role; // 1 admin, 0 user

    public AccountBean(String a, String b, boolean c) {
        fName = a;
        lName = b;
        role = c;
    }

    public String getfName() {
        return fName;
    }

    public String getlName() {
        return lName;
    }

    public void setRole(boolean role) {
        this.role = role;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }
    
    
   
   
}
